package ia.atarax.timer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TimerApplicationTests {

	@Test
	void contextLoads() {
	}

}
